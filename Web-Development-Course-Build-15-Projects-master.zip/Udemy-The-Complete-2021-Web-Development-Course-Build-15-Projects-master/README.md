# Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects

About this course The only course you need to become a full-stack web developer. Covers HTML5, CSS3, JS, ES6, Node, APIs, Mobile & more!

***** Learn and Master Over 10 Modern 2021 Technologies *****

-HTML5/CSS3 -JAVASCRIPT (ES5) -Modern JavaScript (ES6) -JQUERY & JQUERY UI -TWITTER BOOTSTRAP -Node.js -Git & Github -Heroku -PHP & MYSQL -WORDPRESS -AJAX

-JSON -MOBILE APPS -GOOGLE MAPS APIS -FACEBOOK WIDGETS -GOOGLE PLUS WIDGETS -TWITTER WIDGETS -AND MORE!

## Projects 


Math Website (HTML + CSS)
- [Solution](https://sameer-shahzada.github.io/Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects//1.Maths-Website(HTML+CSS)Project/Math-Website.html)
- [Source code](./1.Maths-Website(HTML+CSS)Project/)

Photo Gallery (HTML + CSS)
- [Solution](https://sameer-shahzada.github.io/Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects//2.Photo-Gallery/index.html)
- [Source code](./2.Photo-Gallery/)

Payment Gateway (HTML + CSS)
- [Solution](https://sameer-shahzada.github.io/Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects//3.Payment-Gateway/index.html)
- [Source code](./3.Payment-Gateway/)

Maths Game (HTML + CSS + JavaScript)

- [Solution](https://sameer-shahzada.github.io/Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects//4.Maths-Game(HTML+CSS+JS)/index.html)
- [Source code](./4.Maths-Game(HTML+CSS+JS)/)

Fruits Slice Game (HTML + CSS + Jquery)

- [Solution](https://sameer-shahzada.github.io/Udemy-The-Complete-2021-Web-Development-Course-Build-15-Projects//5.Fruits-Slice-Game/index.html)
- [Source code](./5.Fruits-Slice-Game/)



